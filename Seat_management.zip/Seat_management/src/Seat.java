import java.util.Timer;
import java.util.TimerTask;

public class Seat {
    private int row;
    private int number;
    private boolean isBooked;
    private boolean isLocked;
    private Timer timer;

    public Seat(int row, int number) {
        this.row = row;
        this.number = number;
        this.isBooked = false;
        this.isLocked = false;
    }

    public int getRow() {
        return row;
    }

    public int getNumber() {
        return number;
    }

    public boolean isBooked() {
        return isBooked;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public void book() {
        this.isBooked = true;
        this.isLocked = false;
        cancelTimer();
    }

    public void lock() {
        if (!isBooked && !isLocked) {
            this.isLocked = true;
            startTimer();
        }
    }

    public void release() {
        if (isLocked) {
            this.isLocked = false;
            cancelTimer();
            System.out.println("Seat " + row + "-" + number + " has been released.");
        }
    }

    private void startTimer() {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                release();
            }
        }, 60000); // lock duration: 60 seconds
    }

    private void cancelTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    @Override
    public String toString() {
        return "Row " + row + " Seat " + number + (isBooked ? " [Booked]" : (isLocked ? " [Locked]" : " [Available]"));
    }
}
