import java.util.List;

public class Movie {
    private String title;
    private String genre;
    private List<String> showtimes;

    public Movie(String title, String genre, List<String> showtimes) {
        this.title = title;
        this.genre = genre;
        this.showtimes = showtimes;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public List<String> getShowtimes() {
        return showtimes;
    }

    @Override
    public String toString() {
        return title + " (" + genre + ") - Showtimes: " + showtimes;
    }
}
