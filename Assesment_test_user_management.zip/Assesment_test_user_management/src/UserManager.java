import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private Map<String, User> users;

    public UserManager() {
        users = new HashMap<>();
    }

    public boolean registerUser(String name, String email, String password) {
        if (users.containsKey(email)) {
            return false; // User already exists
        }
        users.put(email, new User(name, email, password));
        return true;
    }

    public User loginUser(String email, String password) {
        User user = users.get(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
}
