import java.util.ArrayList;
import java.util.List;

public class Show {
    private Movie movie;
    private String showtime;
    private List<Seat> seats;

    public Show(Movie movie, String showtime, int rows, int seatsPerRow) {
        this.movie = movie;
        this.showtime = showtime;
        this.seats = new ArrayList<>();
        for (int row = 1; row <= rows; row++) {
            for (int number = 1; number <= seatsPerRow; number++) {
                this.seats.add(new Seat(row, number));
            }
        }
    }

    public Movie getMovie() {
        return movie;
    }

    public String getShowtime() {
        return showtime;
    }

    public List<Seat> getSeats() {
        return seats;
    }

    @Override
    public String toString() {
        return "Showtime: " + showtime + " - " + movie;
    }
}
