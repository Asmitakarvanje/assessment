import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookingSystem {
    private List<Movie> movies;
    private List<Show> shows;
    private Scanner scanner;

    public BookingSystem() {
        movies = new ArrayList<>();
        shows = new ArrayList<>();
        scanner = new Scanner(System.in);
        initializeMoviesAndShows();
    }

    private void initializeMoviesAndShows() {
        // Add sample movies and shows
        List<String> showtimes1 = List.of("12:00 PM", "3:00 PM", "6:00 PM");
        List<String> showtimes2 = List.of("1:00 PM", "4:00 PM", "7:00 PM");

        Movie movie1 = new Movie("The Matrix", "Action/Sci-Fi", showtimes1);
        Movie movie2 = new Movie("Inception", "Action/Sci-Fi", showtimes2);

        movies.add(movie1);
        movies.add(movie2);

        for (String showtime : showtimes1) {
            shows.add(new Show(movie1, showtime, 5, 10));
        }

        for (String showtime : showtimes2) {
            shows.add(new Show(movie2, showtime, 5, 10));
        }
    }

    public void displayMovies() {
        System.out.println("Available Movies:");
        for (int i = 0; i < movies.size(); i++) {
            System.out.println((i + 1) + ". " + movies.get(i));
        }
    }

    public void displayShows() {
        System.out.println("Available Shows:");
        for (int i = 0; i < shows.size(); i++) {
            System.out.println((i + 1) + ". " + shows.get(i));
        }
    }

    public Show selectShow() {
        displayShows();
        System.out.print("Select a show by entering the corresponding number: ");
        int showIndex = scanner.nextInt() - 1;
        scanner.nextLine(); // consume newline
        if (showIndex >= 0 && showIndex < shows.size()) {
            return shows.get(showIndex);
        } else {
            System.out.println("Invalid selection.");
            return null;
        }
    }

    public void displaySeats(Show show) {
        System.out.println("Seating Arrangement for " + show.getMovie().getTitle() + " at " + show.getShowtime());
        for (Seat seat : show.getSeats()) {
            System.out.print(seat + " ");
            if (seat.getNumber() == 10) {
                System.out.println(); // new row
            }
        }
        System.out.println();
    }

    public List<Seat> selectSeats(Show show, int numberOfSeats) {
        List<Seat> selectedSeats = new ArrayList<>();
        displaySeats(show);
        for (int i = 0; i < numberOfSeats; i++) {
            System.out.print("Enter row number for seat " + (i + 1) + ": ");
            int row = scanner.nextInt();
            System.out.print("Enter seat number for seat " + (i + 1) + ": ");
            int seatNumber = scanner.nextInt();
            scanner.nextLine(); // consume newline

            for (Seat seat : show.getSeats()) {
                if (seat.getRow() == row && seat.getNumber() == seatNumber) {
                    if (!seat.isBooked()) {
                        seat.book();
                        selectedSeats.add(seat);
                    } else {
                        System.out.println("Seat already booked. Please choose a different seat.");
                        i--;
                    }
                    break;
                }
            }
        }
        return selectedSeats;
    }

    public void bookTickets() {
        Show show = selectShow();
        if (show == null) {
            return;
        }
        System.out.print("Enter number of tickets: ");
        int numberOfTickets = scanner.nextInt();
        scanner.nextLine(); // consume newline

        List<Seat> selectedSeats = selectSeats(show, numberOfTickets);

        if (selectedSeats.size() == numberOfTickets) {
            // Proceed to payment (dummy implementation)
            System.out.print("Enter payment amount: ");
            double amount = scanner.nextDouble();
            scanner.nextLine(); // consume newline
            System.out.println("Payment successful. Booking confirmed!");

            // Display booking confirmation
            System.out.println("Booking Confirmation:");
            System.out.println("Movie: " + show.getMovie().getTitle());
            System.out.println("Showtime: " + show.getShowtime());
            System.out.println("Seats: " + selectedSeats);
            System.out.println("Total Price: $" + amount);
        } else {
            System.out.println("Booking failed. Please try again.");
        }
    }

    public static void main(String[] args) {
        BookingSystem bookingSystem = new BookingSystem();
        bookingSystem.bookTickets();
    }
}
